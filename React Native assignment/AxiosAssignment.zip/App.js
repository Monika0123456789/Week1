import React, { useEffect, useState } from 'react';
import { View, Text, Image } from 'react-native';
import axios from 'axios';
import { ScrollView } from 'react-native';

export default function App() {
  const [userData, setUserData] = useState([]);

  useEffect(() => {
    axios.get('https://reqres.in/api/users?page=1')
      .then((response) => setUserData(response.data.data))
      .catch((err) => console.log("Data not loaded", err));
  }, []);

  return (
    <ScrollView>
      <View>
        {userData.map((val) => (
          <View key={val.id} style={{ width: 200, height: 200, borderTopColor: "black", borderTopWidth: 30, marginTop: 20 }}>
            <Text>{val.first_name} {val.last_name}</Text>
            <Image source={{ uri: val.avatar, width: 150, height: 150 }} />
          </View>
        ))}
      </View>
    </ScrollView>
  );
}
