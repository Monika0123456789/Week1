import React, { useState, useEffect } from 'react';
import { View, TextInput, Button, StyleSheet, Text, FlatList, TouchableOpacity } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function App() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [age, setAge] = useState('');
  const [storedData, setStoredData] = useState([]);

  const fetchData = async () => {
    try {
      const storedDataString = await AsyncStorage.getItem('formData');
      const parsedData = JSON.parse(storedDataString) || [];
      setStoredData(parsedData);
    } catch (error) {
      console.error('Error fetching stored data:', error);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleSubmit = async () => {
    try {
      const newData = {
        name,
        email,
        phone,
        address,
        age,
      };

      
      const existingDataString = await AsyncStorage.getItem('formData');
      let existingData = JSON.parse(existingDataString) || [];

     
      if (!Array.isArray(existingData)) {
        existingData = [];
      }

      const updatedData = [...existingData, newData];

      await AsyncStorage.setItem('formData', JSON.stringify(updatedData));

      console.log('Form data stored successfully in local storage.');

      setName('');
      setEmail('');
      setPhone('');
      setAddress('');
      setAge('');

      fetchData(); 
    } catch (error) {
      console.error('Error storing form data:', error);
    }
  };

  const handleDelete = async (index) => {
    try {
      const updatedData = [...storedData];
      updatedData.splice(index, 1);
      await AsyncStorage.setItem('formData', JSON.stringify(updatedData));
      setStoredData(updatedData);
    } catch (error) {
      console.error('Error deleting form data:', error);
    }
  };

  return (
    <View style={styles.container}>
      <TextInput
        style={styles.input}
        placeholder="Enter your name"
        onChangeText={(text) => setName(text)}
        value={name}
      />
      <TextInput
        style={styles.input}
        placeholder="Enter your email"
        onChangeText={(text) => setEmail(text)}
        value={email}
        keyboardType="email-address"
      />
      <TextInput
        style={styles.input}
        placeholder="Enter your phone number"
        onChangeText={(text) => setPhone(text)}
        value={phone}
        keyboardType="phone-pad"
      />
      <TextInput
        style={styles.input}
        placeholder="Enter your address"
        onChangeText={(text) => setAddress(text)}
        value={address}
      />
      <TextInput
        style={styles.input}
        placeholder="Enter your age"
        onChangeText={(text) => setAge(text)}
        value={age}
        keyboardType="numeric"
      />
      <Button title="Submit" onPress={handleSubmit} />
      <FlatList
        data={storedData}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item, index }) => (
          <View style={styles.storedItem}>
            <Text>Name: {item.name}</Text>
            <Text>Email: {item.email}</Text>
            <Text>Phone: {item.phone}</Text>
            <Text>Address: {item.address}</Text>
            <Text>Age: {item.age}</Text>
            <TouchableOpacity onPress={() => handleDelete(index)}>
              <Text style={styles.deleteButton}>Delete</Text>
            </TouchableOpacity>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 16,
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 16,
    padding: 8,
  },
  storedItem: {
    marginTop: 16,
    padding: 8,
    borderWidth: 1,
    borderColor: 'lightgray',
  },
  deleteButton: {
    color: 'red',
    marginTop: 8,
  },
});
