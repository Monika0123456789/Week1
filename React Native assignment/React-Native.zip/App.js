import {   ScrollView, Text, View } from "react-native"
import { Header } from "./components/header";
import BodyComp from "./components/body";
 
export default App = () => {
return (
     <ScrollView>
    
     <View style={{marginTop:20}}>
      <Header/>
      <BodyComp/>
     </View>
   
    </ScrollView>

  );

};