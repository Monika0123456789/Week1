import React from "react";
import { View, Image } from "react-native";

export const Header = () => {
  return (
    <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', width: 100, height: 100,gap:280}}>
      <Image style={{ width: 50, height: 50, borderRadius: 10, backgroundColor: 'red' }} source={require("../assets/Images/antman.jpg")} />
      <Image style={{ width: 50, height: 50, borderRadius: 50, backgroundColor: 'red' }} source={require("../assets/Images/batman.jpg")} />
    </View>
  );
};

export default Header;
