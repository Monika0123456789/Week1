import { StatusBar } from 'expo-status-bar';
import { Text, View } from 'react-native';
import HomeComp from './components/home';
import Batman from './components/batman';
import WonderWomen from './components/wonderwomen';
import Superman from './components/superman';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import HeroScreen from './components/homescreen';

const Stack = createNativeStackNavigator();
export default function App() {
  return <NavigationContainer>
   <Stack.Navigator>
    <Stack.Screen name='Home' component={HomeComp}/>
    <Stack.Screen name='HeroScreen' component={HeroScreen} />
   </Stack.Navigator>
  </NavigationContainer>
}


