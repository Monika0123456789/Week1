import React from 'react';
import { SafeAreaView, View, Text, Button } from 'react-native';
import { style } from './styles';
import HeroScreen from './homescreen';
import data from './data.json';

export default function HomeComp({ navigation }) {
  const navigateToHero = (hero) => {
    navigation.navigate('HeroScreen', { herolist: data.herolist, selectedHero: hero });
  };

  return (
    <SafeAreaView>
      <View style={style.container}>
        <Text style={style.title}>I am HomeComp</Text>
        {data.herolist.map((hero) => (
          <Button
            key={hero.sl}
            title={hero.title}
            onPress={() => navigateToHero(hero)}
          />
        ))}
      </View>
    </SafeAreaView>
  );
}
