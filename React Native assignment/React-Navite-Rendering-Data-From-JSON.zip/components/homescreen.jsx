import React from 'react';
import { View, Text, Image } from 'react-native';

export default function HeroScreen({ route }) {
  const { herolist, selectedHero } = route.params;

  const heroDetails = herolist?.find((hero) => hero.title === selectedHero.title);

 return (
    <View style={{display:'flex',justifyContent:'center',alignItems:'center'}}>
      <Text style={{fontSize:30,marginBottom:10}}>TITLE : {heroDetails.title}</Text>
      <Text style={{fontSize:30,marginBottom:10}}>Name :{`${heroDetails.firstname} ${heroDetails.lastname}`}</Text>
      <Text style={{fontSize:30,marginBottom:10}}>City :{heroDetails.city}</Text>
      <Text style={{fontSize:30,marginBottom:10}}>Gender :{heroDetails.gender}</Text>
      <Text style={{fontSize:30,marginBottom:10}}>ReleaseDate :{heroDetails.releasedate}</Text>
      <Image source={{ uri: heroDetails.poster }} style={{ width: 200, height: 300 }} />
    </View>
  );
}
