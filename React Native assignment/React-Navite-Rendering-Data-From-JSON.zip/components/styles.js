 import {StyleSheet} from "react-native";
 export const style = StyleSheet.create(
  {
    title : {
      fontSize :20,
      backgroundColor : "silver",
      textAlign : "center",
      fontWeight : "bold"
    },
    container: {
      display:"flex",
      justifyContent : "center",
      alignItems : "center"
    }
  }
)