import {  Text, View,Image } from "react-native";
export let  BodyComp = () => {
  return <View style={{display:"flex",flexDirection:"column",justifyContent:"space-around"}}>
  <View style={{display:"flex",flexDirection:"row"}}>
  <View>
  <Image style={{width:200,height:200,position:"relative",margin:8,marginRight:2}} source={require("../assets/Images/antman.jpg")}/>
  <Text style={{position:"absolute",color:"white",marginLeft:10,marginTop:130,fontWeight:"bold",}}>AntMan</Text>  
  </View>
  <View>
  <Image style={{width:200,height:200,position:"relative",margin:8,marginRight:2}} source={require("../assets/Images/antman.jpg")}/>
  <Text style={{position:"absolute",color:"white",marginLeft:10,marginTop:130,fontWeight:"bold"}}>AntMan</Text>  
  </View>
  </View>
 
 <View style={{display:"flex",flexDirection:"row"}}>
  <View>
  <Image style={{width:200,height:200,position:"relative",margin:8,marginRight:2}} source={require("../assets/Images/antman.jpg")}/>
  <Text style={{position:"absolute",color:"white",marginLeft:10,marginTop:130,fontWeight:"bold"}}>AntMan</Text>  
  </View>
  <View>
  <Image style={{width:200,height:200,position:"relative",margin:8,marginRight:2}} source={require("../assets/Images/antman.jpg")}/>
  <Text style={{position:"absolute",color:"white",marginLeft:10,marginTop:130,fontWeight:"bold"}}>AntMan</Text>
  </View>
</View>
 
<View style={{display:"flex",flexDirection:"row"}}>
  <View>
  <Image style={{width:200,height:200,position:"relative",margin:8,marginRight:2}} source={require("../assets/Images/antman.jpg")}/>
  <Text style={{position:"absolute",color:"white",marginLeft:10,marginTop:130,fontWeight:"bold",}}>AntMan</Text>  
  </View>
  <View>
  <Image style={{width:200,height:200,position:"relative",margin:8,marginRight:2}} source={require("../assets/Images/antman.jpg")}/>
  <Text style={{position:"absolute",color:"white",marginLeft:10,marginTop:130,fontWeight:"bold"}}>AntMan</Text>  
  </View>
  </View>
 
 <View style={{display:"flex",flexDirection:"row"}}>
  <View>
  <Image style={{width:200,height:200,position:"relative",margin:8,marginRight:2}} source={require("../assets/Images/antman.jpg")}/>
  <Text style={{position:"absolute",color:"white",marginLeft:10,marginTop:130,fontWeight:"bold"}}>AntMan</Text>  
  </View>
  <View>
  <Image style={{width:200,height:200,position:"relative",margin:8,marginRight:2}} source={require("../assets/Images/antman.jpg")}/>
  <Text style={{position:"absolute",color:"white",marginLeft:10,marginTop:130,fontWeight:"bold"}}>AntMan</Text>
  </View>
</View>
 
  <View>
  <Image style={{width:200,height:200,position:"relative",margin:8,marginRight:2}} source={require("../assets/Images/antman.jpg")}/>
  <Text style={{position:"absolute",color:"white",marginLeft:10,marginTop:130,fontWeight:"bold"}}>AntMan</Text>  
  </View>
 
 
  </View>
}
export default BodyComp;
