import React, { useState } from 'react';
import { ScrollView, View, StyleSheet, TouchableWithoutFeedback } from 'react-native';

const styles = StyleSheet.create({
  box: { height: 200, marginBottom: 10 },
  firstBox: { marginTop: 50, width: '50%', backgroundColor: 'red' },
  widthincrease: { width: '100%' },
});

export default function App() {
  const [widthchange, setWidth] = useState(false);

  const handleBoxPress = () => {
    setWidth(!widthchange);
  };

  return (
    <ScrollView>
      <View>
        <TouchableWithoutFeedback onPress={handleBoxPress}>
          <View style={[styles.box, styles.firstBox, widthchange && styles.widthincrease]}></View>
        </TouchableWithoutFeedback>
        <View style={{ ...styles.box, backgroundColor: 'cyan' }}></View>
        <View style={{ ...styles.box, backgroundColor: 'cyan' }}></View>
        <View style={{ ...styles.box, backgroundColor: 'cyan' }}></View>
        <View style={[styles.box, { backgroundColor: 'cyan' }]}></View>
       </View>
    </ScrollView>
  );
}
