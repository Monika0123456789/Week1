import { Component } from "react";
import axios from "axios";
 
class App extends Component{
    state = {
        User : []
    }

    componentDidMount(){ 
      axios.get("https://reqres.in/api/users?page=2")
      .then(res => this.setState({User : res.data.data}))
      .catch (err => console.log(err))
    }
    render(){
      return <div>
                  <h1>Ajax|API call</h1>
                  <hr />
                  <ol>
                   {this.state.User.map(val=><li key={val.id}><img src={val.avatar} alt={val.first_name+" "+val.last_name} width="100"></img>{val.first_name+" "+val.last_name}</li>)}

                  </ol>
                
              </div>
   }
}
 
export default App;