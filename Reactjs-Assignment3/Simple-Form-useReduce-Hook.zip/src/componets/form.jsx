import { useReducer, useRef } from "react";

export let AppForm = () => {
  let reducerFun = (state, action) => {
    switch (action.type) {
      case "SET_VALUES":
        return { ...state, ...action.payload };
      default:
        return state;
    }
  };

  let [store, dispatch] = useReducer(reducerFun, {
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
  });

  let ipFirstName = useRef();
  let ipLastName = useRef();
  let ipEmail = useRef();
  let ipPhone = useRef();

  return <div>
      <h1>Use Reducer Hook</h1>
      <form 
        onSubmit={(evt) => {
          evt.preventDefault();
          dispatch({
            type: "SET_VALUES",
            payload: {
              firstName: ipFirstName.current.value,
              lastName: ipLastName.current.value,
              email: ipEmail.current.value,
              phone: ipPhone.current.value
            }
          });
        }}
      >
        <label>First Name:</label>
        <input type="text" ref={ipFirstName} />
        <br />
        <label>Last Name:</label>
        <input type="text" ref={ipLastName} />
        <br />
        <label>Email ID:</label>
        <input type="email" ref={ipEmail} />
        <br />
        <label>Phone No:</label>
        <input type="number" ref={ipPhone} />
        <br />
        <button type="submit">Submit</button>
      </form>
      <hr />
      <h2>Form Output</h2>
      <p>First Name: {store.firstName}</p>
      <p>Last Name: {store.lastName}</p>
      <p>Email: {store.email}</p>
      <p>Phone: {store.phone}</p>
    </div>
  
};
