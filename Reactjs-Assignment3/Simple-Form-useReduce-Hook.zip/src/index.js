import {createRoot} from "react-dom/client";
import { AppForm } from "./componets/form";

createRoot(document.getElementById("root"))
.render(<AppForm />)